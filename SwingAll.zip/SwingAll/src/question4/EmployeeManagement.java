package question4;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.sql.*;

public class EmployeeManagement extends JFrame {

	private JPanel contentPane;
	private JTextField txtID, txtName, txtDept, txtSalary;
	private JTable table;
	private DefaultTableModel tableModel;
	private JLabel lblTotalSalary;

	// Database Credentials
	String url = "jdbc:mysql://localhost:3306/RegistrationForm";
	String dbUser = "root";
	String dbPass = "Shash@135";

	public static void main(String[] args) {
		EventQueue.invokeLater(() -> {
			try {
				EmployeeManagement frame = new EmployeeManagement();
				frame.setVisible(true);
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
	}

	public EmployeeManagement() {
		setTitle("Employee Management System");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 900, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(15, 15));

		// --- Left Panel: Input Form ---
		JPanel inputPanel = new JPanel(new GridLayout(12, 1, 5, 5));
		inputPanel.setPreferredSize(new Dimension(250, 400));
		inputPanel.setBorder(BorderFactory.createTitledBorder("Employee Details"));

		inputPanel.add(new JLabel("Employee ID (for Update/Del):"));
		txtID = new JTextField();
		inputPanel.add(txtID);

		inputPanel.add(new JLabel("Full Name:"));
		txtName = new JTextField();
		inputPanel.add(txtName);

		inputPanel.add(new JLabel("Department:"));
		txtDept = new JTextField();
		inputPanel.add(txtDept);

		inputPanel.add(new JLabel("Salary:"));
		txtSalary = new JTextField();
		inputPanel.add(txtSalary);

		JButton btnAdd = new JButton("Add Employee");
		JButton btnUpdate = new JButton("Update Salary/Dept");
		JButton btnDelete = new JButton("Remove Employee");
		inputPanel.add(new JLabel("")); // Spacer
		inputPanel.add(btnAdd);
		inputPanel.add(btnUpdate);
		inputPanel.add(btnDelete);

		contentPane.add(inputPanel, BorderLayout.WEST);

		// --- Center Panel: Table & Stats ---
		JPanel centerPanel = new JPanel(new BorderLayout(10, 10));
		tableModel = new DefaultTableModel(new String[]{"ID", "Name", "Department", "Salary"}, 0);
		table = new JTable(tableModel);
		centerPanel.add(new JScrollPane(table), BorderLayout.CENTER);

		// Bottom Stats Panel
		JPanel statsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		lblTotalSalary = new JLabel("Total Payroll: $0.00");
		lblTotalSalary.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblTotalSalary.setForeground(new Color(0, 102, 51));
		statsPanel.add(lblTotalSalary);
		centerPanel.add(statsPanel, BorderLayout.SOUTH);

		contentPane.add(centerPanel, BorderLayout.CENTER);

		// --- Database Logic ---

		btnAdd.addActionListener(e -> {
			executeSQL("INSERT INTO employees (name, department, salary) VALUES (?, ?, ?)",
					txtName.getText(), txtDept.getText(), txtSalary.getText());
			refreshData();
		});

		btnUpdate.addActionListener(e -> {
			executeSQL("UPDATE employees SET department=?, salary=? WHERE id=?",
					txtDept.getText(), txtSalary.getText(), txtID.getText());
			refreshData();
		});

		btnDelete.addActionListener(e -> {
			executeSQL("DELETE FROM employees WHERE id=?", txtID.getText());
			refreshData();
		});

		refreshData(); // Initial load
	}

	private void refreshData() {
		loadTableData();
		calculateTotalSalary();
		clearFields();
	}

	private void loadTableData() {
		try (Connection con = DriverManager.getConnection(url, dbUser, dbPass);
			 Statement st = con.createStatement();
			 ResultSet rs = st.executeQuery("SELECT * FROM employees")) {
			tableModel.setRowCount(0);
			while (rs.next()) {
				tableModel.addRow(new Object[]{
						rs.getInt("id"), rs.getString("name"), 
						rs.getString("department"), rs.getDouble("salary")
				});
			}
		} catch (SQLException ex) { ex.printStackTrace(); }
	}

	private void calculateTotalSalary() {
		try (Connection con = DriverManager.getConnection(url, dbUser, dbPass);
			 Statement st = con.createStatement();
			 ResultSet rs = st.executeQuery("SELECT SUM(salary) as total FROM employees")) {
			if (rs.next()) {
				double total = rs.getDouble("total");
				lblTotalSalary.setText("Total Payroll: $" + String.format("%.2f", total));
			}
		} catch (SQLException ex) { ex.printStackTrace(); }
	}

	private void executeSQL(String sql, String... params) {
		try (Connection con = DriverManager.getConnection(url, dbUser, dbPass);
			 PreparedStatement pst = con.prepareStatement(sql)) {
			for (int i = 0; i < params.length; i++) {
				pst.setString(i + 1, params[i]);
			}
			pst.executeUpdate();
		} catch (SQLException ex) {
			JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
		}
	}

	private void clearFields() {
		txtID.setText(""); txtName.setText(""); txtDept.setText(""); txtSalary.setText("");
	}
}