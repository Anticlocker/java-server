package question1;

import javax.swing.*;
import java.awt.Font;

public class WelcomeScreen extends JFrame {
    public WelcomeScreen(String user) {
        setTitle("Dashboard");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        JLabel welcomeLabel = new JLabel("Welcome, " + user + "!");
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 20));
        welcomeLabel.setHorizontalAlignment(SwingConstants.CENTER);
        add(welcomeLabel);
    }
}