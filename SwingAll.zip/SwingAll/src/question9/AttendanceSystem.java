package question9;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.sql.*;

public class AttendanceSystem extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JComboBox<String> comboStudent;
	private JTextField txtDate;
	private JComboBox<String> comboStatus;
	private JTable attendanceTable;
	private DefaultTableModel tableModel;

	// Database Credentials
	private final String url = "jdbc:mysql://localhost:3306/AttendanceDB";
	private final String dbUser = "root";
	private final String dbPass = "Shash@135";

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AttendanceSystem frame = new AttendanceSystem();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AttendanceSystem() {
		setTitle("Student Attendance System");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 500);
		
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
		contentPane.setLayout(new GridLayout(1, 2, 20, 0));
		setContentPane(contentPane);

		// --- LEFT PANEL: Input Form ---
		JPanel leftPanel = new JPanel(new BorderLayout(10, 10));
		leftPanel.setBorder(BorderFactory.createTitledBorder("Mark Attendance"));

		JPanel inputFields = new JPanel(new GridLayout(4, 2, 5, 10));
		
		inputFields.add(new JLabel("Select Student:"));
		comboStudent = new JComboBox<>();
		inputFields.add(comboStudent);

		inputFields.add(new JLabel("Date (YYYY-MM-DD):"));
		// Auto-populate current date for convenience
		txtDate = new JTextField(new java.text.SimpleDateFormat("yyyy-MM-dd").format(new java.util.Date()));
		inputFields.add(txtDate);

		inputFields.add(new JLabel("Status:"));
		String[] statusOptions = {"Present", "Absent"};
		comboStatus = new JComboBox<>(statusOptions);
		inputFields.add(comboStatus);

		leftPanel.add(inputFields, BorderLayout.NORTH);

		// Save Button
		JButton btnSave = new JButton("Save Attendance Record");
		leftPanel.add(btnSave, BorderLayout.SOUTH);

		// --- RIGHT PANEL: View History ---
		JPanel rightPanel = new JPanel(new BorderLayout(10, 10));
		rightPanel.setBorder(BorderFactory.createTitledBorder("Attendance Log / Records"));

		tableModel = new DefaultTableModel(new String[]{"ID", "Student Name", "Date", "Status"}, 0) {
			@Override
			public boolean isCellEditable(int row, int column) {
				return false; // Read-only
			}
		};
		attendanceTable = new JTable(tableModel);
		rightPanel.add(new JScrollPane(attendanceTable), BorderLayout.CENTER);

		JButton btnRefresh = new JButton("Refresh Attendance Records");
		rightPanel.add(btnRefresh, BorderLayout.SOUTH);

		// Adding both panels to main content pane
		contentPane.add(leftPanel);
		contentPane.add(rightPanel);

		// --- Event Listeners and Database Operations ---

		btnSave.addActionListener(e -> saveAttendance());
		btnRefresh.addActionListener(e -> loadAttendanceHistory());

		// Populate dropdown and history on startup
		loadStudentsDropdown();
		loadAttendanceHistory();
	}

	/**
	 * Populates the student combobox directly from the database.
	 */
	private void loadStudentsDropdown() {
		String sql = "SELECT student_id, student_name FROM students ORDER BY student_name ASC";
		try (Connection con = DriverManager.getConnection(url, dbUser, dbPass);
			 Statement st = con.createStatement();
			 ResultSet rs = st.executeQuery(sql)) {

			comboStudent.removeAllItems();
			while (rs.next()) {
				// Display format: "ID - Name"
				String item = rs.getInt("student_id") + " - " + rs.getString("student_name");
				comboStudent.addItem(item);
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
			JOptionPane.showMessageDialog(this, "Failed to load student list.");
		}
	}

	/**
	 * Saves the attendance record into the database.
	 */
	private void saveAttendance() {
		if (comboStudent.getSelectedItem() == null || txtDate.getText().trim().isEmpty()) {
			JOptionPane.showMessageDialog(this, "All fields are required.", "Error", JOptionPane.ERROR_MESSAGE);
			return;
		}

		// Extract student ID from the combined string "ID - Name"
		String selectedItem = comboStudent.getSelectedItem().toString();
		int studentId = Integer.parseInt(selectedItem.split(" - ")[0]);
		String dateStr = txtDate.getText().trim();
		String status = comboStatus.getSelectedItem().toString();

		// UPSERT strategy: Insert, and if it already exists for that student + date, update the status instead.
		String sql = "INSERT INTO attendance (student_id, attendance_date, status) VALUES (?, ?, ?) "
				   + "ON DUPLICATE KEY UPDATE status = ?";

		try (Connection con = DriverManager.getConnection(url, dbUser, dbPass);
			 PreparedStatement pst = con.prepareStatement(sql)) {

			pst.setInt(1, studentId);
			pst.setString(2, dateStr);
			pst.setString(3, status);
			pst.setString(4, status); // for updating existing record

			pst.executeUpdate();
			JOptionPane.showMessageDialog(this, "Attendance marked successfully!");
			loadAttendanceHistory();

		} catch (SQLException ex) {
			ex.printStackTrace();
			JOptionPane.showMessageDialog(this, "Error: Check date format (YYYY-MM-DD) or connection details.");
		}
	}

	/**
	 * Loads attendance history by joining attendance and students tables.
	 */
	private void loadAttendanceHistory() {
		String sql = "SELECT a.attendance_id, s.student_name, a.attendance_date, a.status "
				   + "FROM attendance a JOIN students s ON a.student_id = s.student_id "
				   + "ORDER BY a.attendance_date DESC, a.attendance_id DESC";

		try (Connection con = DriverManager.getConnection(url, dbUser, dbPass);
			 Statement st = con.createStatement();
			 ResultSet rs = st.executeQuery(sql)) {

			tableModel.setRowCount(0);
			while (rs.next()) {
				tableModel.addRow(new Object[]{
						rs.getInt("attendance_id"),
						rs.getString("student_name"),
						rs.getDate("attendance_date"),
						rs.getString("status")
				});
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
			JOptionPane.showMessageDialog(this, "Failed to fetch attendance history.");
		}
	}
}