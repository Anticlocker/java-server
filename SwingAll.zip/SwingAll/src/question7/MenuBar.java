package question7;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class MenuBar extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MenuBar frame = new MenuBar();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MenuBar() {
		setTitle("Standard Menu System");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 500, 350);
		
		// Setup the main content pane
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);

		// A friendly placeholder label in the center of the window
		JLabel lblWelcome = new JLabel("Click any menu item above to test functionality", SwingConstants.CENTER);
		lblWelcome.setFont(new Font("Tahoma", Font.PLAIN, 14));
		contentPane.add(lblWelcome, BorderLayout.CENTER);

		// --- Setup the Menu Bar ---
		JMenuBar menuBar = new JMenuBar();

		// 1. File Menu & Items
		JMenu fileMenu = new JMenu("File");
		JMenuItem itemNew = new JMenuItem("New");
		JMenuItem itemOpen = new JMenuItem("Open");
		JMenuItem itemExit = new JMenuItem("Exit");

		fileMenu.add(itemNew);
		fileMenu.add(itemOpen);
		fileMenu.addSeparator(); // Visually separates general actions from terminal actions
		fileMenu.add(itemExit);

		// 2. Edit Menu & Items
		JMenu editMenu = new JMenu("Edit");
		JMenuItem itemCut = new JMenuItem("Cut");
		JMenuItem itemCopy = new JMenuItem("Copy");
		JMenuItem itemPaste = new JMenuItem("Paste");

		editMenu.add(itemCut);
		editMenu.add(itemCopy);
		editMenu.add(itemPaste);

		// Add menus to the menu bar
		menuBar.add(fileMenu);
		menuBar.add(editMenu);

		// Set the completed menu bar onto the frame
		setJMenuBar(menuBar);

		// --- Setup Event Action Listeners ---

		itemNew.addActionListener(e -> showMessage("File -> New clicked"));
		itemOpen.addActionListener(e -> showMessage("File -> Open clicked"));
		
		itemExit.addActionListener(e -> {
			int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to exit?", "Exit Application", JOptionPane.YES_NO_OPTION);
			if (confirm == JOptionPane.YES_OPTION) {
				System.exit(0);
			}
		});

		itemCut.addActionListener(e -> showMessage("Edit -> Cut clicked"));
		itemCopy.addActionListener(e -> showMessage("Edit -> Copy clicked"));
		itemPaste.addActionListener(e -> showMessage("Edit -> Paste clicked"));
	}

	/**
	 * Helper method to cleanly display user selections.
	 */
	private void showMessage(String msg) {
		JOptionPane.showMessageDialog(this, msg, "Menu Action", JOptionPane.INFORMATION_MESSAGE);
	}
}