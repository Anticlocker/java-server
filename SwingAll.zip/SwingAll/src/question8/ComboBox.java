package question8;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridLayout;
import java.sql.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class ComboBox extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JComboBox<String> comboDept;
	private JLabel lblSelection;

	// Database Credentials
	private final String url = "jdbc:mysql://localhost:3306/CompanyDB";
	private final String dbUser = "root";
	private final String dbPass = "Shash@135";

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ComboBox frame = new ComboBox();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ComboBox() {
		setTitle("Department Selection Tool");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 500, 300);
		
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(20, 20, 20, 20));
		contentPane.setLayout(new BorderLayout(10, 20));
		setContentPane(contentPane);

		// --- Center Panel: Form Components ---
		JPanel centerPanel = new JPanel(new GridLayout(2, 1, 10, 10));
		
		JPanel row1 = new JPanel(new BorderLayout(10, 10));
		JLabel lblChoose = new JLabel("Select Department:");
		lblChoose.setFont(new Font("Tahoma", Font.BOLD, 12));
		
		comboDept = new JComboBox<>();
		comboDept.setFont(new Font("Tahoma", Font.PLAIN, 12));
		
		row1.add(lblChoose, BorderLayout.WEST);
		row1.add(comboDept, BorderLayout.CENTER);
		centerPanel.add(row1);

		// Selection Output Label
		lblSelection = new JLabel("No department selected yet.", SwingConstants.CENTER);
		lblSelection.setFont(new Font("Tahoma", Font.ITALIC, 13));
		centerPanel.add(lblSelection);

		contentPane.add(centerPanel, BorderLayout.CENTER);

		// --- South Panel: Refresh Button ---
		JButton btnRefresh = new JButton("Load / Refresh Departments");
		contentPane.add(btnRefresh, BorderLayout.SOUTH);

		// --- Event Listeners and Database Operations ---
		
		// Event handler for selecting a department from the combo box
		comboDept.addActionListener(e -> {
			if (comboDept.getSelectedItem() != null) {
				String selected = comboDept.getSelectedItem().toString();
				lblSelection.setText("You selected: " + selected);
			}
		});

		// Refresh data action listener
		btnRefresh.addActionListener(e -> loadDepartments());

		// Auto-populate on startup
		loadDepartments();
	}

	/**
	 * Retrieves department records from the database and inserts them into the JComboBox.
	 */
	private void loadDepartments() {
		String sql = "SELECT dept_name FROM departments ORDER BY dept_name ASC";
		
		try (Connection con = DriverManager.getConnection(url, dbUser, dbPass);
			 Statement st = con.createStatement();
			 ResultSet rs = st.executeQuery(sql)) {

			// Clear the JComboBox to avoid duplicates on refresh
			comboDept.removeAllItems();

			boolean dataFound = false;
			while (rs.next()) {
				comboDept.addItem(rs.getString("dept_name"));
				dataFound = true;
			}

			if (!dataFound) {
				lblSelection.setText("No departments found in the database.");
			} else {
				// Resets the initial selection state
				comboDept.setSelectedIndex(0);
			}

		} catch (SQLException ex) {
			ex.printStackTrace();
			JOptionPane.showMessageDialog(this, "Failed to load departments: " + ex.getMessage(), 
					"Database Error", JOptionPane.ERROR_MESSAGE);
		}
	}
}