package question6;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.sql.*;

public class ProductInventory extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField txtName, txtQty, txtPrice;
    private JComboBox<String> comboCategory;
    private JTable inventoryTable;
    private DefaultTableModel tableModel;

    // Selected product ID for updates or deletions
    private int selectedProductId = -1;

    // Database Credentials
    private final String url = "jdbc:mysql://localhost:3306/InventoryDB";
    private final String dbUser = "root";
    private final String dbPass = "Shash@135";

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                ProductInventory frame = new ProductInventory();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public ProductInventory() {
        setTitle("Product Inventory Management System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 1050, 550);
        
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        setContentPane(contentPane);
        contentPane.setLayout(new GridLayout(1, 2, 20, 0));

        // --- LEFT PANEL: Product Entry Form ---
        JPanel leftPanel = new JPanel(new BorderLayout(10, 10));
        leftPanel.setBorder(BorderFactory.createTitledBorder("Manage Product Details"));

        JPanel inputFields = new JPanel(new GridLayout(5, 2, 5, 10));
        
        inputFields.add(new JLabel("Product Name:"));
        txtName = new JTextField();
        inputFields.add(txtName);

        inputFields.add(new JLabel("Quantity:"));
        txtQty = new JTextField();
        inputFields.add(txtQty);

        inputFields.add(new JLabel("Price ($):"));
        txtPrice = new JTextField();
        inputFields.add(txtPrice);

        inputFields.add(new JLabel("Category:"));
        String[] categories = {"Electronics", "Groceries", "Clothing", "Furniture", "Books"};
        comboCategory = new JComboBox<>(categories);
        inputFields.add(comboCategory);

        leftPanel.add(inputFields, BorderLayout.NORTH);

        // CRUD Button Panel
        JPanel buttonPanel = new JPanel(new GridLayout(2, 2, 10, 10));
        JButton btnAdd = new JButton("Add Product");
        JButton btnUpdate = new JButton("Update Stock");
        JButton btnDelete = new JButton("Delete Product");
        JButton btnClear = new JButton("Clear Form");

        buttonPanel.add(btnAdd);
        buttonPanel.add(btnUpdate);
        buttonPanel.add(btnDelete);
        buttonPanel.add(btnClear);
        leftPanel.add(buttonPanel, BorderLayout.SOUTH);

        // --- RIGHT PANEL: Inventory Viewer (JTable) ---
        JPanel rightPanel = new JPanel(new BorderLayout(10, 10));
        rightPanel.setBorder(BorderFactory.createTitledBorder("Current Inventory Status"));

        tableModel = new DefaultTableModel(new String[]{"ID", "Product Name", "Qty", "Price", "Category"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Makes the JTable read-only
            }
        };
        inventoryTable = new JTable(tableModel);
        rightPanel.add(new JScrollPane(inventoryTable), BorderLayout.CENTER);

        JButton btnRefresh = new JButton("Refresh Inventory View");
        rightPanel.add(btnRefresh, BorderLayout.SOUTH);

        // Adding both panels to the main layout
        contentPane.add(leftPanel);
        contentPane.add(rightPanel);

        // --- Event Listeners and Logic ---

        // Selection Listener: Clicking on a table row loads data back into the text fields
        inventoryTable.getSelectionModel().addListSelectionListener(e -> {
            int selectedRow = inventoryTable.getSelectedRow();
            if (selectedRow != -1) {
                selectedProductId = Integer.parseInt(tableModel.getValueAt(selectedRow, 0).toString());
                txtName.setText(tableModel.getValueAt(selectedRow, 1).toString());
                txtQty.setText(tableModel.getValueAt(selectedRow, 2).toString());
                txtPrice.setText(tableModel.getValueAt(selectedRow, 3).toString());
                comboCategory.setSelectedItem(tableModel.getValueAt(selectedRow, 4).toString());
            }
        });

        btnAdd.addActionListener(e -> addProduct());
        btnUpdate.addActionListener(e -> updateProduct());
        btnDelete.addActionListener(e -> deleteProduct());
        btnClear.addActionListener(e -> clearForm());
        btnRefresh.addActionListener(e -> loadInventory());

        // Load data on startup
        loadInventory();
    }

    private void addProduct() {
        if (validateInputs()) {
            String sql = "INSERT INTO products (product_name, quantity, price, category) VALUES (?, ?, ?, ?)";
            try (Connection con = DriverManager.getConnection(url, dbUser, dbPass);
                 PreparedStatement pst = con.prepareStatement(sql)) {

                pst.setString(1, txtName.getText().trim());
                pst.setInt(2, Integer.parseInt(txtQty.getText().trim()));
                pst.setDouble(3, Double.parseDouble(txtPrice.getText().trim()));
                pst.setString(4, comboCategory.getSelectedItem().toString());

                pst.executeUpdate();
                JOptionPane.showMessageDialog(this, "Product successfully added!");
                clearForm();
                loadInventory();
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Database Error: " + ex.getMessage());
            }
        }
    }

    private void updateProduct() {
        if (selectedProductId == -1) {
            JOptionPane.showMessageDialog(this, "Please select a product from the table first.");
            return;
        }

        if (validateInputs()) {
            String sql = "UPDATE products SET product_name = ?, quantity = ?, price = ?, category = ? WHERE product_id = ?";
            try (Connection con = DriverManager.getConnection(url, dbUser, dbPass);
                 PreparedStatement pst = con.prepareStatement(sql)) {

                pst.setString(1, txtName.getText().trim());
                pst.setInt(2, Integer.parseInt(txtQty.getText().trim()));
                pst.setDouble(3, Double.parseDouble(txtPrice.getText().trim()));
                pst.setString(4, comboCategory.getSelectedItem().toString());
                pst.setInt(5, selectedProductId);

                pst.executeUpdate();
                JOptionPane.showMessageDialog(this, "Product updated successfully!");
                clearForm();
                loadInventory();
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Database Error: " + ex.getMessage());
            }
        }
    }

    private void deleteProduct() {
        if (selectedProductId == -1) {
            JOptionPane.showMessageDialog(this, "Please select a product from the table to delete.");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this product?", 
                "Confirm Deletion", JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            String sql = "DELETE FROM products WHERE product_id = ?";
            try (Connection con = DriverManager.getConnection(url, dbUser, dbPass);
                 PreparedStatement pst = con.prepareStatement(sql)) {

                pst.setInt(1, selectedProductId);
                pst.executeUpdate();

                JOptionPane.showMessageDialog(this, "Product deleted successfully!");
                clearForm();
                loadInventory();
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Database Error: " + ex.getMessage());
            }
        }
    }

    private void loadInventory() {
        String sql = "SELECT * FROM products ORDER BY product_id DESC";
        try (Connection con = DriverManager.getConnection(url, dbUser, dbPass);
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            tableModel.setRowCount(0);
            while (rs.next()) {
                tableModel.addRow(new Object[]{
                        rs.getInt("product_id"),
                        rs.getString("product_name"),
                        rs.getInt("quantity"),
                        rs.getDouble("price"),
                        rs.getString("category")
                });
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Failed to fetch inventory: " + ex.getMessage());
        }
    }

    private boolean validateInputs() {
        if (txtName.getText().trim().isEmpty() || txtQty.getText().trim().isEmpty() || txtPrice.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "All input fields are required.");
            return false;
        }
        try {
            int qty = Integer.parseInt(txtQty.getText().trim());
            double price = Double.parseDouble(txtPrice.getText().trim());
            if (qty < 0 || price < 0) {
                JOptionPane.showMessageDialog(this, "Quantity and Price must be positive numbers.");
                return false;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter valid numbers for Quantity and Price.");
            return false;
        }
        return true;
    }

    private void clearForm() {
        txtName.setText("");
        txtQty.setText("");
        txtPrice.setText("");
        comboCategory.setSelectedIndex(0);
        inventoryTable.clearSelection();
        selectedProductId = -1;
    }
}