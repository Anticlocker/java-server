package question5;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.util.ArrayList;

public class InvoiceGenerator extends JFrame {

    private JPanel contentPane;
    private JTextField txtProduct, txtPrice, txtQty;
    private JTable itemTable, historyTable;
    private DefaultTableModel itemModel, historyModel;
    private JLabel lblGrandTotal;
    private double grandTotal = 0.0;

    // Database Credentials
    String url = "jdbc:mysql://localhost:3306/RegistrationForm";
    String dbUser = "root";
    String dbPass = "Shash@135";

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                InvoiceGenerator frame = new InvoiceGenerator();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public InvoiceGenerator() {
        setTitle("Shop Invoice System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 1000, 600);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        setContentPane(contentPane);
        contentPane.setLayout(new GridLayout(1, 2, 20, 0));

        // --- LEFT SIDE: Create New Invoice ---
        JPanel leftPanel = new JPanel(new BorderLayout(10, 10));
        leftPanel.setBorder(BorderFactory.createTitledBorder("New Invoice"));

        JPanel inputFields = new JPanel(new GridLayout(4, 2, 5, 5));
        inputFields.add(new JLabel("Product Name:"));
        txtProduct = new JTextField();
        inputFields.add(txtProduct);
        inputFields.add(new JLabel("Price:"));
        txtPrice = new JTextField();
        inputFields.add(txtPrice);
        inputFields.add(new JLabel("Quantity:"));
        txtQty = new JTextField();
        inputFields.add(txtQty);
        
        JButton btnAddItem = new JButton("Add to List");
        inputFields.add(btnAddItem);
        leftPanel.add(inputFields, BorderLayout.NORTH);

        itemModel = new DefaultTableModel(new String[]{"Product", "Price", "Qty", "Total"}, 0);
        itemTable = new JTable(itemModel);
        leftPanel.add(new JScrollPane(itemTable), BorderLayout.CENTER);

        JPanel bottomLeft = new JPanel(new BorderLayout());
        lblGrandTotal = new JLabel("Grand Total: $0.00");
        lblGrandTotal.setFont(new Font("Tahoma", Font.BOLD, 14));
        bottomLeft.add(lblGrandTotal, BorderLayout.WEST);
        
        JButton btnSave = new JButton("Save & Generate Invoice");
        bottomLeft.add(btnSave, BorderLayout.EAST);
        leftPanel.add(bottomLeft, BorderLayout.SOUTH);

        // --- RIGHT SIDE: Invoice History ---
        JPanel rightPanel = new JPanel(new BorderLayout(10, 10));
        rightPanel.setBorder(BorderFactory.createTitledBorder("Invoice History"));
        
        historyModel = new DefaultTableModel(new String[]{"Inv ID", "Date", "Total Amount"}, 0);
        historyTable = new JTable(historyModel);
        rightPanel.add(new JScrollPane(historyTable), BorderLayout.CENTER);
        
        JButton btnRefresh = new JButton("Refresh History");
        rightPanel.add(btnRefresh, BorderLayout.SOUTH);

        contentPane.add(leftPanel);
        contentPane.add(rightPanel);

        // --- Logic ---

        btnAddItem.addActionListener(e -> {
            String prod = txtProduct.getText();
            double pr = Double.parseDouble(txtPrice.getText());
            int q = Integer.parseInt(txtQty.getText());
            double total = pr * q;
            itemModel.addRow(new Object[]{prod, pr, q, total});
            grandTotal += total;
            lblGrandTotal.setText("Grand Total: $" + String.format("%.2f", grandTotal));
        });

        btnSave.addActionListener(e -> saveInvoice());
        btnRefresh.addActionListener(e -> loadHistory());

        loadHistory();
    }

    private void saveInvoice() {
        try (Connection con = DriverManager.getConnection(url, dbUser, dbPass)) {
            con.setAutoCommit(false); // Start Transaction

            // 1. Insert into Invoices Table
            String sqlInv = "INSERT INTO invoices (total_amount, date) VALUES (?, NOW())";
            PreparedStatement pstInv = con.prepareStatement(sqlInv, Statement.RETURN_GENERATED_KEYS);
            pstInv.setDouble(1, grandTotal);
            pstInv.executeUpdate();

            ResultSet rs = pstInv.getGeneratedKeys();
            if (rs.next()) {
                int invoiceId = rs.getInt(1);

                // 2. Insert all items into invoice_items
                String sqlItem = "INSERT INTO invoice_items (invoice_id, product_name, price, quantity) VALUES (?, ?, ?, ?)";
                PreparedStatement pstItem = con.prepareStatement(sqlItem);

                for (int i = 0; i < itemModel.getRowCount(); i++) {
                    pstItem.setInt(1, invoiceId);
                    pstItem.setString(2, itemModel.getValueAt(i, 0).toString());
                    pstItem.setDouble(3, Double.parseDouble(itemModel.getValueAt(i, 1).toString()));
                    pstItem.setInt(4, Integer.parseInt(itemModel.getValueAt(i, 2).toString()));
                    pstItem.addBatch();
                }
                pstItem.executeBatch();
            }

            con.commit(); // End Transaction
            JOptionPane.showMessageDialog(this, "Invoice Saved Successfully!");
            itemModel.setRowCount(0);
            grandTotal = 0;
            lblGrandTotal.setText("Grand Total: $0.00");
            loadHistory();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void loadHistory() {
        try (Connection con = DriverManager.getConnection(url, dbUser, dbPass);
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM invoices ORDER BY id DESC")) {
            historyModel.setRowCount(0);
            while (rs.next()) {
                historyModel.addRow(new Object[]{rs.getInt("id"), rs.getTimestamp("date"), rs.getDouble("total_amount")});
            }
        } catch (SQLException ex) { ex.printStackTrace(); }
    }
}