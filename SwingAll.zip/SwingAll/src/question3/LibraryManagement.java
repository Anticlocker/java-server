package question3;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.sql.*;

public class LibraryManagement extends JFrame {

	private JPanel contentPane;
	private JTextField txtTitle, txtAuthor, txtISBN, txtQuantity, txtSearch;
	private JTable table;
	private DefaultTableModel tableModel;

	// Database Credentials
	String url = "jdbc:mysql://localhost:3306/RegistrationForm";
	String dbUser = "root";
	String dbPass = "Shash@135";

	public static void main(String[] args) {
		EventQueue.invokeLater(() -> {
			try {
				LibraryManagement frame = new LibraryManagement();
				frame.setVisible(true);
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
	}

	public LibraryManagement() {
		setTitle("Library Inventory System");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 900, 550);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(10, 10));

		// --- Top Panel: Search ---
		JPanel searchPanel = new JPanel();
		searchPanel.add(new JLabel("Search (Title/Author):"));
		txtSearch = new JTextField(20);
		searchPanel.add(txtSearch);
		JButton btnSearch = new JButton("Filter");
		searchPanel.add(btnSearch);
		contentPane.add(searchPanel, BorderLayout.NORTH);

		// --- Left Panel: Input Form ---
		JPanel inputPanel = new JPanel(new GridLayout(10, 1, 5, 5));
		inputPanel.setPreferredSize(new Dimension(250, 400));
		inputPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

		inputPanel.add(new JLabel("Book Title:"));
		txtTitle = new JTextField();
		inputPanel.add(txtTitle);

		inputPanel.add(new JLabel("Author:"));
		txtAuthor = new JTextField();
		inputPanel.add(txtAuthor);

		inputPanel.add(new JLabel("ISBN:"));
		txtISBN = new JTextField();
		inputPanel.add(txtISBN);

		inputPanel.add(new JLabel("Quantity:"));
		txtQuantity = new JTextField();
		inputPanel.add(txtQuantity);

		JButton btnAdd = new JButton("Add Book");
		JButton btnUpdate = new JButton("Update Selected");
		JButton btnDelete = new JButton("Delete Book");
		inputPanel.add(btnAdd);
		inputPanel.add(btnUpdate);
		inputPanel.add(btnDelete);

		contentPane.add(inputPanel, BorderLayout.WEST);

		// --- Center Panel: Table ---
		tableModel = new DefaultTableModel(new String[]{"ID", "Title", "Author", "ISBN", "Qty"}, 0);
		table = new JTable(tableModel);
		contentPane.add(new JScrollPane(table), BorderLayout.CENTER);

		// --- Logic & Database Actions ---

		// ADD BOOK
		btnAdd.addActionListener(e -> {
			executeSQL("INSERT INTO books (title, author, isbn, quantity) VALUES (?, ?, ?, ?)",
					txtTitle.getText(), txtAuthor.getText(), txtISBN.getText(), txtQuantity.getText());
			loadData();
		});

		// UPDATE BOOK
		btnUpdate.addActionListener(e -> {
			int row = table.getSelectedRow();
			if (row != -1) {
				String id = table.getValueAt(row, 0).toString();
				executeSQL("UPDATE books SET title=?, author=?, isbn=?, quantity=? WHERE id=?",
						txtTitle.getText(), txtAuthor.getText(), txtISBN.getText(), txtQuantity.getText(), id);
				loadData();
			}
		});

		// DELETE BOOK
		btnDelete.addActionListener(e -> {
			int row = table.getSelectedRow();
			if (row != -1) {
				String id = table.getValueAt(row, 0).toString();
				executeSQL("DELETE FROM books WHERE id=?", id);
				loadData();
			}
		});

		// SEARCH/FILTER LOGIC
		btnSearch.addActionListener(e -> {
			String text = txtSearch.getText();
			TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(tableModel);
			table.setRowSorter(sorter);
			sorter.setRowFilter(RowFilter.regexFilter("(?i)" + text)); // Case-insensitive filter
		});

		loadData(); // Initial load
	}

	private void executeSQL(String sql, String... params) {
		try (Connection con = DriverManager.getConnection(url, dbUser, dbPass);
			 PreparedStatement pst = con.prepareStatement(sql)) {
			for (int i = 0; i < params.length; i++) {
				pst.setString(i + 1, params[i]);
			}
			pst.executeUpdate();
			clearFields();
		} catch (SQLException ex) {
			JOptionPane.showMessageDialog(this, "Database Error: " + ex.getMessage());
		}
	}

	private void loadData() {
		try (Connection con = DriverManager.getConnection(url, dbUser, dbPass);
			 Statement st = con.createStatement();
			 ResultSet rs = st.executeQuery("SELECT * FROM books")) {
			tableModel.setRowCount(0);
			while (rs.next()) {
				tableModel.addRow(new Object[]{
						rs.getInt("id"), rs.getString("title"), 
						rs.getString("author"), rs.getString("isbn"), rs.getInt("quantity")
				});
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
	}

	private void clearFields() {
		txtTitle.setText(""); txtAuthor.setText(""); txtISBN.setText(""); txtQuantity.setText("");
	}
}