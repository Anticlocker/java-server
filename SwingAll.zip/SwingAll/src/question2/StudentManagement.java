package question2;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.*;
import java.util.Vector;

public class StudentManagement extends JFrame {

    private JPanel contentPane;
    private JTextField txtName, txtRoll, txtCourse;
    private JTable table;
    private DefaultTableModel tableModel;

    // Database Credentials
    String url = "jdbc:mysql://localhost:3306/RegistrationForm";
    String dbUser = "root";
    String dbPass = "Shash@135";

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                StudentManagement frame = new StudentManagement();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public StudentManagement() {
        setTitle("Student Management System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 800, 500);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(new BorderLayout(10, 10));

        // --- Left Panel: Input Fields ---
        JPanel inputPanel = new JPanel();
        inputPanel.setPreferredSize(new Dimension(250, 400));
        inputPanel.setLayout(null);
        contentPane.add(inputPanel, BorderLayout.WEST);

        JLabel lblName = new JLabel("Name:");
        lblName.setBounds(10, 30, 80, 25);
        inputPanel.add(lblName);

        txtName = new JTextField();
        txtName.setBounds(90, 30, 140, 25);
        inputPanel.add(txtName);

        JLabel lblRoll = new JLabel("Roll No:");
        lblRoll.setBounds(10, 70, 80, 25);
        inputPanel.add(lblRoll);

        txtRoll = new JTextField();
        txtRoll.setBounds(90, 70, 140, 25);
        inputPanel.add(txtRoll);

        JLabel lblCourse = new JLabel("Course:");
        lblCourse.setBounds(10, 110, 80, 25);
        inputPanel.add(lblCourse);

        txtCourse = new JTextField();
        txtCourse.setBounds(90, 110, 140, 25);
        inputPanel.add(txtCourse);

        // --- Buttons ---
        JButton btnAdd = new JButton("Add");
        btnAdd.setBounds(10, 160, 100, 30);
        inputPanel.add(btnAdd);

        JButton btnUpdate = new JButton("Update");
        btnUpdate.setBounds(130, 160, 100, 30);
        inputPanel.add(btnUpdate);

        JButton btnDelete = new JButton("Delete");
        btnDelete.setBounds(10, 200, 100, 30);
        inputPanel.add(btnDelete);

        JButton btnClear = new JButton("Clear");
        btnClear.setBounds(130, 200, 100, 30);
        inputPanel.add(btnClear);

        // --- Right Side: JTable ---
        tableModel = new DefaultTableModel(new String[]{"ID", "Name", "Roll No", "Course"}, 0);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        contentPane.add(scrollPane, BorderLayout.CENTER);

        // --- Button Actions ---

        // ADD
        btnAdd.addActionListener(e -> {
            try (Connection con = DriverManager.getConnection(url, dbUser, dbPass)) {
                String sql = "INSERT INTO students (name, roll_no, course) VALUES (?, ?, ?)";
                PreparedStatement pst = con.prepareStatement(sql);
                pst.setString(1, txtName.getText());
                pst.setString(2, txtRoll.getText());
                pst.setString(3, txtCourse.getText());
                pst.executeUpdate();
                updateTable();
                clearFields();
            } catch (SQLException ex) { ex.printStackTrace(); }
        });

        // DELETE
        btnDelete.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row != -1) {
                String id = tableModel.getValueAt(row, 0).toString();
                try (Connection con = DriverManager.getConnection(url, dbUser, dbPass)) {
                    String sql = "DELETE FROM students WHERE id=?";
                    PreparedStatement pst = con.prepareStatement(sql);
                    pst.setString(1, id);
                    pst.executeUpdate();
                    updateTable();
                } catch (SQLException ex) { ex.printStackTrace(); }
            }
        });

        // UPDATE
        btnUpdate.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row != -1) {
                String id = tableModel.getValueAt(row, 0).toString();
                try (Connection con = DriverManager.getConnection(url, dbUser, dbPass)) {
                    String sql = "UPDATE students SET name=?, roll_no=?, course=? WHERE id=?";
                    PreparedStatement pst = con.prepareStatement(sql);
                    pst.setString(1, txtName.getText());
                    pst.setString(2, txtRoll.getText());
                    pst.setString(3, txtCourse.getText());
                    pst.setString(4, id);
                    pst.executeUpdate();
                    updateTable();
                } catch (SQLException ex) { ex.printStackTrace(); }
            }
        });

        updateTable(); // Initial load
    }

    private void updateTable() {
        try (Connection con = DriverManager.getConnection(url, dbUser, dbPass)) {
            String sql = "SELECT * FROM students";
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            tableModel.setRowCount(0);
            while (rs.next()) {
                tableModel.addRow(new Object[]{rs.getInt("id"), rs.getString("name"), rs.getString("roll_no"), rs.getString("course")});
            }
        } catch (SQLException ex) { ex.printStackTrace(); }
    }

    private void clearFields() {
        txtName.setText("");
        txtRoll.setText("");
        txtCourse.setText("");
    }
}