package question1;

import java.awt.EventQueue;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.*;

public class Login extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtUsername;
	private JPasswordField txtPassword;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Login() {
		setTitle("Login Form");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 527, 545);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Login System");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 22));
		lblNewLabel.setBounds(150, 50, 200, 40);
		contentPane.add(lblNewLabel);
		
		JLabel lblUser = new JLabel("UserName:");
		lblUser.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblUser.setBounds(110, 150, 100, 20);
		contentPane.add(lblUser);
		
		JLabel lblPass = new JLabel("Password:");
		lblPass.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblPass.setBounds(110, 200, 100, 20);
		contentPane.add(lblPass);
		
		txtUsername = new JTextField();
		txtUsername.setBounds(230, 150, 150, 25);
		contentPane.add(txtUsername);
		
		txtPassword = new JPasswordField();
		txtPassword.setBounds(230, 200, 150, 25);
		contentPane.add(txtPassword);
		
		JButton btnLogin = new JButton("Login");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String user = txtUsername.getText();
				String pass = new String(txtPassword.getPassword());
				
				String url = "jdbc:mysql://localhost:3306/RegistrationForm";
				String dbUser = "root";
				String dbPass = "Shash@135";

				try {
				
					Connection connection = DriverManager.getConnection(url, dbUser, dbPass);
					
					String query = "SELECT * FROM users WHERE username=? AND password=?";
					PreparedStatement pst = connection.prepareStatement(query);
					pst.setString(1, user);
					pst.setString(2, pass);
					
					
					ResultSet rs = pst.executeQuery();
					
					if (rs.next()) {
						JOptionPane.showMessageDialog(null, "Login Successful!");
						dispose();
						
						
						WelcomeScreen welcome = new WelcomeScreen(user);
						welcome.setVisible(true);
					} else {
						JOptionPane.showMessageDialog(null, "Invalid Username or Password", "Error", JOptionPane.ERROR_MESSAGE);
					}
					
					connection.close();
					
				} catch (SQLException sqlException) {
					sqlException.printStackTrace();
					JOptionPane.showMessageDialog(null, "Database Connection Error");
				}
			}
		});
		btnLogin.setBounds(210, 280, 100, 30);
		contentPane.add(btnLogin);
	}
}